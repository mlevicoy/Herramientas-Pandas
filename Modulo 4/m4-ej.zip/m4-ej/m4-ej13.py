df2 = pd.read_csv("lista_productos.csv",encoding="latin-1")
print("DF: (ventas.csv)")
print(df.dtypes)
print("DF: (lista_productos.csv)")
print(df2.dtypes)

df2["NUM"] = df2["NUM"].astype(str)

print("DF: (ventas.csv)")
print(df.dtypes)
print("DF: (lista_productos.csv)")
print(df2.dtypes)

df = df.merge(df2,on="NUM")

print(df.head())