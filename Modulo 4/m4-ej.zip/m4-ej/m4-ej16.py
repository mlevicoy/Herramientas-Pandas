df["TOTAL"] = df["PRECIO"] * df["CANT"]
print(df.head())