df3 = df.pivot_table(index="MES",values="TOTAL", columns="CAT", aggfunc={np.mean,np.std,np.min,np.max,})
print(df3.head())