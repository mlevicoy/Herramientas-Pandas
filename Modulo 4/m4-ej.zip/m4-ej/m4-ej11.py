import pandas as pd
import numpy as np

df = pd.read_csv("ventas.csv",encoding="latin-1",sep=";")

print(df.head())
df["FECHA"] = df["FECHA"].str.replace("=","/")
print(df.head())