import pandas as pd
df = pd.read_csv("ejemplo.csv",encoding="latin-1",sep=";")

print(df.loc[(df["Nombre"].str.split(" ",expand=True)[0] == "Daniela") & (df["Monto"] < 1000000) & (df["RUT"].str[-1:] == "8")])