import pandas as pd
df = pd.read_csv("ejemplo.csv",encoding="latin-1",sep=";")

df = df.sort_values(by=["Sexo","Monto"],ascending=False)

print(df)