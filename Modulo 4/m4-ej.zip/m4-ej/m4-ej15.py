df_aux = df["FECHA"].str.split("/",expand=True)
df_aux.columns = ["ANHO","MES","DIA"]

df = df.join(df_aux)
print(df.head())

print(df.loc[(df["PRECIO"] < 1000) & (df["CANT"] < 5) & ((df["MES"] == "4") | (df["MES"] == "5"))])