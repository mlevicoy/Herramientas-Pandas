print(df.head())

df["NUM"] = df["NUM"].str.replace(" ","")
df["NUM"] = df["NUM"].str.replace(".","")
df["NUM"] = df["NUM"].str.replace(",","")

print(df.head())