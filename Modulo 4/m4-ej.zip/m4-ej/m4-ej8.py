import pandas as pd
df = pd.read_csv("ejemplo2.csv",encoding="latin-1",sep=";")

df2 = df.pivot(index="RUT",columns="BANCO",values="MONTO")

print(df2)