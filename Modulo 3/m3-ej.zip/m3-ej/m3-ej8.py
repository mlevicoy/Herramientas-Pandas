import pandas as pd
df = pd.read_csv("ejemplo.csv",encoding="latin-1",sep=";")

print(df["Fecha_Nac"].str.replace("/","-"))