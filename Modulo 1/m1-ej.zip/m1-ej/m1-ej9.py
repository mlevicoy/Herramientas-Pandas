import pandas as pd

df = pd.read_csv("clientes.csv",encoding="latin-1",sep=";")

print(df.loc[df['TIPO_CLIENTE'] == "A"])